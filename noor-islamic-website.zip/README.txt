NOOR ISLAMIC — WEBSITE PACKAGE
================================

WHAT'S INSIDE
-------------
noor-islamic.html  — the entire website (HTML + CSS + JavaScript in one file)

This single file IS your whole website. There is nothing else to install or build.


HOW TO MAKE IT LIVE (pick ONE option)
--------------------------------------

OPTION 1 — Netlify Drop (easiest, free, 2 minutes)
  1. Go to https://app.netlify.com/drop
  2. Drag this ZIP's noor-islamic.html file onto the page
  3. Netlify gives you a live link immediately (e.g. yoursite.netlify.app)
  4. You can rename the site and later connect your own domain name for free.

OPTION 2 — GitHub Pages (free)
  1. Create a free GitHub account and a new repository
  2. Upload noor-islamic.html, and rename it to: index.html
  3. In the repository Settings → Pages, enable "Deploy from branch" (main)
  4. Your site goes live at https://yourusername.github.io/your-repo-name

OPTION 3 — Any normal web hosting you already own (cPanel, Hostinger, etc.)
  1. Rename noor-islamic.html to index.html
  2. Upload it to your hosting's public_html (or www) folder using File Manager or FTP
  3. Visit your domain — the site is live


IMPORTANT: LOCATION-BASED FEATURES NEED HTTPS
-----------------------------------------------
Prayer Times (via "Use my location") requires a secure https:// address to
work in the browser. All three options above give you https:// automatically.
It will NOT work if you just double-click the file and open it from your
computer's local disk (file://) — that's a browser security rule, not a bug.


BEFORE YOU GO LIVE — A FEW THINGS TO CONNECT YOURSELF
--------------------------------------------------------
These were intentionally left as clearly-marked placeholders rather than
faked. Search the file for these exact labels to find each spot:

1. CONTACT FORM EMAIL — search for "EMAILJS_CONFIG"
   Create a free account at https://www.emailjs.com, then paste your own
   Public Key, Service ID and Template ID in the three placeholders.
   Until you do this, messages are safely saved in the visitor's own browser
   instead of being lost.

2. SOCIAL SHARE IMAGE — search for "og:title"
   Add two lines with a real image URL and your site's address so links look
   good when shared on WhatsApp/Facebook. Instructions are in a comment right
   above those tags.

3. SOME CONTENT NEEDS A COMMERCIAL LICENSE CHECK BEFORE MONETIZING
   Open the website itself → More → Sources & Licensing. Three items
   (the English Quran translation, the Urdu translation, and the Quran
   recitation audio) are marked "NOT verified for commercial use" — their
   original publishers' terms are either restrictive or unclear. This is
   fine for a free, non-commercial site, but get written permission (or
   swap sources) before running ads or charging for anything.

4. VIDEOS — 5 of 8 categories show real videos from Yaqeen Institute's
   official channel (a verified, freely-licensed source). Quran Recitation,
   Dua and Azkar video categories were intentionally left empty rather than
   filled with unverified content — add videos there yourself once you've
   confirmed the channel's reuse rights.


WHAT WAS TESTED
----------------
Every page, the Urdu/English language switch, Quran text+audio (all 114
surahs), Hadith/Duas/Azkar, Tasbih (with persistence), Prayer Times, Hijri
Calendar, Zakat Calculator, Seerah, Hajj & Umrah guide, Saved items,
Search, dark mode, mobile layout, and the Contact form were run through an
automated browser test (76 checks) before this package was created.
